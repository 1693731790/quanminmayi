<?php
$classFile = 'BCGupcext2.php';
$className = 'BCGupcext2';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
